

from operation_input_helper import get_number_input, get_operation_input
num1 = get_number_input("Enter the first number: ")
operation = get_operation_input()
num2 = get_number_input("Enter the second number: ")
if operation == '+':
    result = num1 + num2
    operation_str = "addition"
elif operation == '-':
    result = num1 - num2
    operation_str = "subtraction"
elif operation == '*':
    result = num1 * num2
    operation_str = "multiplication"
elif operation == '/':
    if num2 != 0:
        result = num1 / num2
        operation_str = "division"

    else:

        result = "undefined"
        operation_str = "division by zero"

if result == "undefined":
    print(f"Error: Cannot perform {operation_str} (division by zero).")
else:
    print(f"The result of {operation_str} between {num1} and {num2} is: {result}") 