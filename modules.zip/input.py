def calc_input(promp: str)->float:
    while true:
        try:
            user_input = input(prompt)
            return float(user_input)
        except ValueError:
            print("invalid try again plz")
def get_operation_input() ->str:
    while true:
        operation = input("choose an operation(+,-,*,/):").strip()
        if operation in['+','-','*','/']:
            return operationelse
            print("invalid operation try again")
 

    